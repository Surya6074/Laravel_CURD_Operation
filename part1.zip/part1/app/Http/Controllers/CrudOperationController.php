<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Hamcrest\Core\HasToString;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CrudOperationController extends Controller
{

    // Add a product

    public function create(Request $request){
        $request->validate([
            'name'=>'required',
            'price'=>'required',
            'date'=>'required',
            'desc'=>'required',
            'img'=>'required|image|mimes:jpeg,png,jpg,gif,svg',
            'color'=>'required',
            'sale'=>'required',
            'state'=>'required',
        ]);

        //colors
        $colors=implode(",",$request->input('color'));
        //image upload
        $img = $request->file('img');
        $imgoriginalname = $img->getClientOriginalName();
        $imgname=time().$imgoriginalname;
        $img->move(public_path('images'),$imgname);
        //database
        $product=new Product();
        $product->p_name=$request->input('name');
        $product->p_price=$request->input('price');
        $product->p_launch_date=$request->input('date');
        $product->p_desc=$request->input('desc');
        $product->p_state=$request->input('state');
        $product->p_sale=$request->input('sale');
        $product->p_img=$imgname;
        $product->p_color=$colors;
        $product->save();
        return redirect('/')->with([
            'msg' => 'Product added successfully',
            'status' => 'success'
        ]);
    }

    // index page

    public function index(){
        $products=Product::all();
        return view('home',compact('products'));
    }

    // show a product

    public function show($id){
        $products=Product::whereId($id)->get();
        return view('showproduct',compact('products'));
    }

    //Edit a product

    public function Edit($id){
        $products=Product::whereId($id)->get();
        return view('editproduct',compact('products'));
    }


    //Updata a product
    public function update(Request $request){
        $colors=implode(",",$request->input('color'));

        // image upload
        $product=Product::find($request->input('p_id'));
        if($product!=null){
        $product->p_name=$request->input('name');
        $product->p_price=$request->input('price');
        $product->p_launch_date=$request->input('date');
        $product->p_desc=$request->input('desc');
        $product->p_state=$request->input('state');
        $product->p_sale=$request->input('sale');
        $product->p_color=$colors;
        // dd($request->input('img'));
        // if($request->hasFile('img')){
            //image upload
        $img = $request->file('img');
        $imgoriginalname = $img->getClientOriginalName();
        $imgname=time().$imgoriginalname;
        $img->move(public_path('images'),$imgname);
        // }
        // else{
            $product->p_img=$imgname;
        // }
        if($product->save()){
            return redirect('/')->with([
                'msg' => 'Product updated successfully',
                'status' => 'success'
            ]);
        }else{
            return redirect('/')->with([
                'msg' => 'Product Not found',
                'status' => 'danger'
            ]);
        }
        }else{
            return redirect('/')->with([
                'msg' => 'Product is Not found',
                'status' => 'danger'
            ]);
        }
    }


    // delete data
    public function delete($id) {
        Product::find($id)->delete();
        return redirect('/')->with(['msg'=>'Product Deleted Successfully','status'=>'success']);
    }

    //auto complete search bar data
    public function autocom(Request $request){
        $data = $request->json('res');
        $autolist=DB::select('SELECT * FROM products WHERE p_name LIKE "'.$data.'%";');
        foreach ($autolist as $list){
            $lists[]= (object) array('id' => $list->id, 'name' => $list->p_name);
        }
        return response()->json(['data'=>$lists,'msg'=>'successs']);
    }
}



