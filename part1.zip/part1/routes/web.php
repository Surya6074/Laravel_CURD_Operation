<?php

use App\Http\Controllers\CrudOperationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[CrudOperationController::class,'index']);
Route::get('/show/{id}',[CrudOperationController::class,'show']);
Route::get('/edit/{id}',[CrudOperationController::class,'Edit']);


Route::get('/addproduct', function () {
    return view('addproduct');
});

// Post data routes
Route::post('/product',[CrudOperationController::class,'create']);
Route::put('/editproduct',[CrudOperationController::class,'update']);

Route::get('/delete/{id}',[CrudOperationController::class,'delete']);

Route::post('/auto',[CrudOperationController::class,'autocom']);
