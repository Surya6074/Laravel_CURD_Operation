@extends('layouts.app')
@section('content')
<div class="add-product">
    <h1>Edit product</h1>
    <form action="/editproduct" id="insertForm" method="POST" enctype="multipart/form-data">
    @method('PUT')
    @csrf
    @foreach ($products as $product)

    <div class="input-boxs">
        <div class="col-1">
          <div class="inp">
            <label for="name">Product Name</label>
            <input type="text" name="name" placeholder="Product Name" value="{{$product->p_name}}"/>
        </div>
        <div class="inp">
            <label for="price">Product Price</label>
            <input
            type="number"
            name="price"
            value="{{$product->p_price}}"
            placeholder="Enter a Product Price"
            />
        </div>

        <div class="inp">
            <label for="date">Launch date</label>
            <input type="date" name="date" value="{{$product->p_launch_date}}" />
        </div>
        <div class="inp">
            <label for="state">State </label>
            <select name="state" value="{{$product->p_state}}">
                <option value="Tamilnadu">Tamil Nadu</option>
                <option value="Kerala">Kerala</option>
                <option value="Karnataka">Karnataka</option>
            </select>
        </div>
    </div>
    @php
    $colors = explode(',', $product->p_color);
    @endphp
    <div class="col-1">
        <div class="inp">
            <label for="color">Colors</label>
            <div class="col">
                <div class="color">
                <input type="checkbox" name="color[]" value="Red" {{(in_array("Red",$colors))?'checked':''}} />&nbsp;Red
            </div>
              <div class="color">
                  <input type="checkbox" name="color[]" value="White" {{(in_array("White",$colors))?'checked':''}}/>&nbsp;White
                </div>
                <div class="color">
                    <input type="checkbox" name="color[]" value="Black" {{(in_array("Black",$colors))?'checked':''}}/>&nbsp;Black
                </div>
                <div class="color">
                    <input type="checkbox" name="color[]" value="Gray" {{(in_array("Gray",$colors))?'checked':''}}/>&nbsp;Gray
                </div>
                <div class="color">
                    <input type="checkbox" name="color[]" value="Blue" {{(in_array("Blue",$colors))?'checked':''}}/>&nbsp;Blue
                </div>
            </div>
        </div>
          <div class="inp">
              <label for="sale">Sale or not</label>
              <div class="sale">
                  <div class="sa">
                      <input type="radio" name="sale" value="On sale" {{(strcmp('Not for Sale',$product->p_sale)==0)?'':'checked'}} />&nbsp;Sale
                    </div>
              <div class="sa">
                  <input type="radio" name="sale" value="Not for Sale" {{(strcmp('Not for Sale',$product->p_sale)==0)?'checked':''}} />&nbsp;Not
                  Sale
                </div>
            </div>
        </div>

        <div class="inp">
            <label for="img">Product Image</label>
            <div class="img-inp">
                <input type="text" name="imagename" placeholder="Select a select image" value="{{$product->p_img}}">
                <button type="button" onclick="showimg()" class="btn-edit">change</button>
            </div>
            <div class="img-show" id="image-inp">
                <input
                type="file"
                name="img"
                />
            </div>
        </div>
        <div class="inp">
            <label for="desc">Product Description</label>
            <textarea
            name="desc"
              id=""
              placeholder="Product Description"
              >{{$product->p_desc}}</textarea>
            </div>
        </div>
    </div>
      <div class="btn-groups">
          <a href="/" class="back">Back
          </a>
          <input type="reset" class="reset" />

          <input type="submit" id="btnsubmit" class="submit" />
        </div>
        <input type="hidden" name="p_id" value="{{$product->id}}">
        @endforeach
    </form>
  </div>
<script>
    $(document).ready(function(){$('#image-inp').hide()});
    function showimg(){
        $('#image-inp').slideToggle()()
    }
</script>

  @endsection
