<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{asset('css/style.css')}}" />
    <script
      src="https://code.jquery.com/jquery-3.7.1.min.js"
      integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
      crossorigin="anonymous"
    ></script>
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="{{asset('js/script.js')}}"></script>
    <script src="{{asset('js/Search.js')}}">
    </script>
  </head>
  <body>

    <ul class="errr-msg">
        @if (session('msg'))
        <li class="toast {{session('status')}}">
            <p>{{session('msg')}}</p>
            <div class="toast-progress {{session('status')}}"></div>
        </li>
        @endif
        @if ($errors->any())
            {!! implode('',$errors->all('<li class="toast danger"><p>:message</p><div class="toast-progress danger"></div></li>'))   !!}
        @endif
    </ul>

    <nav>
      <h1>Laravel CRUD</h1>
      <div class="search">
        <i class="bx bx-search"></i>
        <input type="text" placeholder="Search a product" id="search" />
        <div id="autocomplete">
        </div>
      </div>
      <a href="/addproduct" class="btn-edit">Add product</a>
    </nav>
    @yield('content')

</body>
</html>
