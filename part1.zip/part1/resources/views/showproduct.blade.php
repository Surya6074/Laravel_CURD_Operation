@extends('layouts.app')
@section('content')
<div class="view-product">
    @foreach ($products as $product)
    <div class="view-img">
        <img src="{{asset("images/".$product->p_img)}}" alt="products" />
    </div>
    <div class="view-content">
        <div class="cont">
            <h1>{{$product->p_name}}</h1>
        </div>
      <div class="cont">
          <p>{{$product->p_desc}}
        </p>
    </div>
    <div class="cont">
        <h2>${{$product->p_price}}</h2>
    </div>
    <div class="cont">
        <p>Colors : <span>{{$product->p_color}}</span></p>
      </div>

      <div class="cont">
          <p>launch date : <span>{{$product->p_launch_date}}</span></p>
        </div>

        <div class="cont">
            <p>State : <span>{{$product->p_state}}</span></p>
        </div>
        <div class="cont">
            <p>Sale : <span>{{$product->p_sale}}</span></p>
        </div>
        <div class="btn-groups">
            <a href="/" class="back"> Back </a>
        </div>
    </div>
    @endforeach
  </div>
@endsection
