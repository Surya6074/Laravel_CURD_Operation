@extends('layouts.app')
@section('content')
<div class="home">
    <div class="home-content">
        @foreach ($products as $product )
        <div class="card">
            <span class="sale-batch {{($product->p_sale=='Not for Sale')?'not-sale':'on-sale'}}">
                {{$product->p_sale}}
            </span>
            <div class="img">
                <img src="{{asset('images/'.$product->p_img)}}" alt="Products" width="200px" height="200px" />
            </div>
            <div class="card-body">
                <h1>{{$product->p_name}}</h1>
                <p>${{$product->p_price}}</p>
                <div class="btn-groups">
                    <a href="/show/{{$product->id}}" class="btn-view">View</a>
                    <a href="/edit/{{$product->id}}" class="btn-edit">Edit</a>
                    <a onclick="return confirm('Are You Want to Delete a Product')" href="/delete/{{$product->id}}" class="btn-del">Delete</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>
  </div>
@endsection
