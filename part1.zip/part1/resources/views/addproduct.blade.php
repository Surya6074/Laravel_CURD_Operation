@extends('layouts.app')
@section('content')
<div class="add-product">
    <h1>Add product</h1>
    <form action="/product" method="POST" id="insertForm" enctype="multipart/form-data">
        @csrf
      <div class="input-boxs">
        <div class="col-1">
          <div class="inp">
            <label for="name">Enter a Product Name</label>
            <input type="text" name="name" placeholder="Product Name" />
          </div>
          <div class="inp">
            <label for="price">Enter a Product Price</label>
            <input
              type="number"
              name="price"
              placeholder="Enter a Product Price"
            />
          </div>

          <div class="inp">
            <label for="date">Enter launch date</label>
            <input type="date" name="date" />
          </div>
          <div class="inp">
            <label for="state"> Select state </label>
            <select name="state">
              <option value="Tamilnadu">Tamil Nadu</option>
              <option value="Kerala">Kerala</option>
              <option value="Karnataka">Karnataka</option>
            </select>
          </div>
        </div>
        <div class="col-1">
          <div class="inp">
            <label for="color">Select a colors</label>
            <div class="col">
              <div class="color">
                <input type="checkbox" name="color[]" value="Red"/>&nbsp;Red
              </div>
              <div class="color">
                <input type="checkbox" name="color[]" value="White"/>&nbsp;White
              </div>
              <div class="color">
                <input type="checkbox" name="color[]" value="Black"/>&nbsp;Black
              </div>
              <div class="color">
                <input type="checkbox" name="color[]" value="Gray"/>&nbsp;Gray
              </div>
              <div class="color">
                <input type="checkbox" name="color[]" value="Blue"/>&nbsp;Blue
              </div>
            </div>
          </div>
          <div class="inp">
            <label for="sale">Sale or not</label>
            <div class="sale">
              <div class="sa">
                <input type="radio" name="sale" value="On sale" />&nbsp;Sale
              </div>
              <div class="sa">
                <input type="radio" name="sale" value="Not for Sale" />&nbsp;Not
                Sale
              </div>
            </div>
          </div>

          <div class="inp">
            <label for="img">Select a product Image</label>
            <input
              type="file"
              name="img"
            />
          </div>
          <div class="inp">
            <label for="desc">Enter a Product Description</label>
            <textarea
              name="desc"
              id=""
              placeholder="Product Description"
            ></textarea>
          </div>
        </div>
      </div>
      <div class="btn-groups"><a href="/" class="back">Back
      </a>

        <input type="reset" class="reset" />

        <input type="submit" id="btnsubmit" class="submit" />
      </div>
    </form>
  </div>
@endsection
