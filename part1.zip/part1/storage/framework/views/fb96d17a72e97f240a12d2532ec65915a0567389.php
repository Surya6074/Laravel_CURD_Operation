<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <script
      src="https://code.jquery.com/jquery-3.7.1.min.js"
      integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="
      crossorigin="anonymous"
    ></script>
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Search.js')); ?>">
    </script>
  </head>
  <body>

    <ul class="errr-msg">
        <?php if(session('msg')): ?>
        <li class="toast <?php echo e(session('status')); ?>">
            <p><?php echo e(session('msg')); ?></p>
            <div class="toast-progress <?php echo e(session('status')); ?>"></div>
        </li>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php echo implode('',$errors->all('<li class="toast danger"><p>:message</p><div class="toast-progress danger"></div></li>')); ?>

        <?php endif; ?>
    </ul>

    <nav>
      <h1>Laravel CRUD</h1>
      <div class="search">
        <i class="bx bx-search"></i>
        <input type="text" placeholder="Search a product" id="search" />
        <div id="autocomplete">
        </div>
      </div>
      <a href="/addproduct" class="btn-edit">Add product</a>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-tutor\Laravel_Crud\resources\views/layouts/app.blade.php ENDPATH**/ ?>