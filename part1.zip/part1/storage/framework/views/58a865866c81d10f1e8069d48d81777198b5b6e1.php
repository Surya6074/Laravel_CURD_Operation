<?php $__env->startSection('content'); ?>
<div class="view-product">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="view-img">
        <img src="<?php echo e(asset("images/".$product->p_img)); ?>" alt="products" />
    </div>
    <div class="view-content">
        <div class="cont">
            <h1><?php echo e($product->p_name); ?></h1>
        </div>
      <div class="cont">
          <p><?php echo e($product->p_desc); ?>

        </p>
    </div>
    <div class="cont">
        <h2>$<?php echo e($product->p_price); ?></h2>
    </div>
    <div class="cont">
        <p>Colors : <span><?php echo e($product->p_color); ?></span></p>
      </div>

      <div class="cont">
          <p>launch date : <span><?php echo e($product->p_launch_date); ?></span></p>
        </div>

        <div class="cont">
            <p>State : <span><?php echo e($product->p_state); ?></span></p>
        </div>
        <div class="cont">
            <p>Sale : <span><?php echo e($product->p_sale); ?></span></p>
        </div>
        <div class="btn-groups">
            <a href="/" class="back"> Back </a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-tutor\Laravel_Crud\resources\views/showproduct.blade.php ENDPATH**/ ?>