<?php $__env->startSection('content'); ?>
<div class="home">
    <div class="home-content">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <span class="sale-batch <?php echo e(($product->p_sale=='Not for Sale')?'not-sale':'on-sale'); ?>">
                <?php echo e($product->p_sale); ?>

            </span>
            <div class="img">
                <img src="<?php echo e(asset('images/'.$product->p_img)); ?>" alt="Products" width="200px" height="200px" />
            </div>
            <div class="card-body">
                <h1><?php echo e($product->p_name); ?></h1>
                <p>$<?php echo e($product->p_price); ?></p>
                <div class="btn-groups">
                    <a href="/show/<?php echo e($product->id); ?>" class="btn-view">View</a>
                    <a href="/edit/<?php echo e($product->id); ?>" class="btn-edit">Edit</a>
                    <a onclick="return confirm('Are You Want to Delete a Product')" href="/delete/<?php echo e($product->id); ?>" class="btn-del">Delete</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-tutor\Laravel_Crud\resources\views/home.blade.php ENDPATH**/ ?>