$(document).ready(function () {
    $("#insertForm").validate({
        rules: {
            name: {
                required: true,
            },
            price: {
                required: true,
            },
            date: {
                required: true,
            },
            sale: {
                required: true,
            },
            state: {
                required: true,
            },
            "color[]": {
                required: true,
                minlength: 1,
            },
            desc: {
                required: true,
            },
            img: {
                required: true,
            },
        },
        messages: {
            name: {
                required: "This feild is required",
            },
            price: {
                required: "This feild is required",
            },
            date: {
                required: "This feild is required",
            },
            sale: {
                required: "This feild is required",
            },
            state: {
                required: "This feild is required",
            },
            color: {
                required: "This feild is required",
            },
            img: {
                required: "This feild is required",
            },
            desc: {
                required: "This feild is required",
            },
        },
        errorPlacement: function (error, element) {
            if (
                element.attr("type") == "radio" ||
                element.attr("type") == "checkbox"
            ) {
                error.insertBefore(element.first());
            } else {
                error.insertAfter(element);
            }
        },
    });
});

$("#btnsubmit").click(function () {
    if ($("#insertForm").valid()) {
        $("#insertForm").submit();
    }
});
