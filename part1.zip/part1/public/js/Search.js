$(document).ready(function () {
    $("#autocomplete").hide();
    $("#search").on("keyup", function (e) {
        $("#autocomplete").show();
        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
        });
        var data = {
            res: e.target.value,
        };
        $.ajax({
            url: "/auto",
            type: "POST",
            data: JSON.stringify(data),
            success: function (res) {
                console.log(res);
                removechildren();
                var data = res.data;
                for (i = 0; i < data.length; i++) {
                    $("#autocomplete").append(
                        "<a href='/show/" +
                            data[i].id +
                            "' class='result'>" +
                            data[i].name +
                            "</a>"
                    );
                }
            },
        });
    });
});

$("#search").on("keydown", function () {
    $("#autocomplete").hide();
});

function deletesearch() {
    $("#autocomplete").hide();
}

function removechildren() {
    var autodata = document.getElementById("autocomplete");
    for (i = 0; i < autodata.childElementCount; i++) {
        autodata.removeChild(autodata.children[i]);
    }
}
